package Midterms;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Stack;

public class Function implements LibrarySystem {
    private ArrayList<String> books;
    private Stack<String> undoStack;
    private Stack<String> redoStack;
    private Stack<Integer> undoIndexStack; // Track the index for undo
    private Stack<Integer> redoIndexStack; // Track the index for redo

    public Function() {
        books = new ArrayList<>();
        undoStack = new Stack<>();
        redoStack = new Stack<>();
        undoIndexStack = new Stack<>();
        redoIndexStack = new Stack<>();
    }

    @Override
    public void addBook(String bookName) {
        undoStack.push(bookName); // Push the book to undo stack
        undoIndexStack.push(books.size()); // Track index for undo
        books.add(bookName);
        redoStack.clear(); // Clear redo stack when new action occurs
        redoIndexStack.clear();
    }

    @Override
    public void removeBook(int index) {
        if (index >= 0 && index < books.size()) {
            undoStack.push(books.get(index)); // Push removed book to undo stack
            undoIndexStack.push(index); // Track index of removed book for undo
            books.remove(index);
            redoStack.clear(); // Clear redo stack when new action occurs
            redoIndexStack.clear();
        }
    }

    @Override
    public String getBook(int index) {
        if (index < 0 || index >= books.size()) {
            return "Invalid index";
        }
        return books.get(index);
    }

    @Override
    public int getTotalBooks() {
        return books.size();
    }

    @Override
    public Component getBooks() {
        return null; // Not implemented
    }

    public void undo() {
        if (!undoStack.isEmpty() && !undoIndexStack.isEmpty()) {
            String bookName = undoStack.pop();
            int index = undoIndexStack.pop();

            redoStack.push(bookName); // Push to redo stack for redo functionality
            redoIndexStack.push(index); // Track index for redo

            if (index < books.size() && books.get(index).equals(bookName)) {
                books.remove(index); // Remove the last added book for undo
            } else {
                books.add(index, bookName); // Re-add a previously removed book
            }
        }
    }

    public void redo() {
        if (!redoStack.isEmpty() && !redoIndexStack.isEmpty()) {
            String bookName = redoStack.pop();
            int index = redoIndexStack.pop();

            undoStack.push(bookName); // Push back to undo stack
            undoIndexStack.push(index); // Track index for undo

            if (index <= books.size()) {
                books.add(index, bookName); // Re-add the book that was undone
            }
        }
    }

    @Override
    public void insertBook(int index, String bookName) {
        if (index >= 0 && index <= books.size()) {
            books.add(index, bookName);
            undoStack.push(bookName); // Track inserted book for undo
            undoIndexStack.push(index); // Track inserted index for undo
            redoStack.clear(); // Clear redo stack when new action occurs
            redoIndexStack.clear();
        }
    }

    @Override
    public String[] sortbooks() {
        return sortBooks(); // Delegate to the sortBooks method
    }

    public String[] sortBooks() {
        // Bubble Sort Algorithm
        String[] sortedBooks = books.toArray(new String[0]);
        int n = sortedBooks.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (sortedBooks[j].compareTo(sortedBooks[j + 1]) > 0) {
                    // Swap sortedBooks[j] and sortedBooks[j + 1]
                    String temp = sortedBooks[j];
                    sortedBooks[j] = sortedBooks[j + 1];
                    sortedBooks[j + 1] = temp;
                }
            }
        }
        return sortedBooks;
    }
}
