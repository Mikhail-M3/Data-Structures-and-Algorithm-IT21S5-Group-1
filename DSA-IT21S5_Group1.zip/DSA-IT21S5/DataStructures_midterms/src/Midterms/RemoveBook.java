package Midterms;

import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RemoveBook extends JFrame {
    private static final long serialVersionUID = 1L;
    private LibrarySystem library;
    private DefaultTableModel tableModel;
    private JTextField textField;

    public RemoveBook(LibrarySystem library) {
        this.library = library;
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 883, 560);
        getContentPane().setLayout(null);

        String[] columnNames = {"Position", "Name"};
        tableModel = new DefaultTableModel(columnNames, 0); 
        JTable table = new JTable(tableModel);

        updateTable();

        table.setFont(new Font("Arial", Font.PLAIN, 16));
        table.setRowHeight(30);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 18));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(50, 125, 767, 285);
        getContentPane().add(scrollPane);

        JButton btnBack = new JButton("Back");
        btnBack.setForeground(new Color(255, 255, 255));
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Book tr = new Book(library);
                tr.setVisible(true);
                dispose();
            }
        });
        btnBack.setFont(new Font("Arial", Font.BOLD, 20));
        btnBack.setBorder(UIManager.getBorder("ToolBar.border"));
        btnBack.setBackground(new Color(255, 128, 128));
        btnBack.setBounds(50, 449, 150, 30);
        getContentPane().add(btnBack);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(0, 128, 192));
        panel.setBounds(0, 0, 867, 89);
        getContentPane().add(panel);

        JLabel Logo = new JLabel("");
        Logo.setBounds(30, 9, 80, 73);
        panel.add(Logo);

        JLabel Title = new JLabel("BookWorm Library System");
        Title.setHorizontalAlignment(SwingConstants.CENTER);
        Title.setForeground(Color.WHITE);
        Title.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 35));
        Title.setBounds(150, 15, 595, 54);
        panel.add(Title);

        JLabel Logo_1 = new JLabel("");
        Logo_1.setIcon(new ImageIcon("C:\\Users\\User\\Downloads\\IT21S5\\IT21S5_DSA\\img\\logo2.png"));
        Logo_1.setBounds(20, 9, 80, 73);
        panel.add(Logo_1);

        JLabel lblNewLabel = new JLabel("List of Books");
        lblNewLabel.setBounds(346, 87, 124, 44);
        getContentPane().add(lblNewLabel);
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 19));

        JButton btnNewButton = new JButton("Remove");
        btnNewButton.setForeground(new Color(255, 255, 255));
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String positionText = textField.getText().trim(); 

                if (positionText.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter a valid position.", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (!isNumeric(positionText)) {
                    JOptionPane.showMessageDialog(null, "Invalid position. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    int position = Integer.parseInt(positionText);

                    if (position < 0 || position >= library.getTotalBooks()) {
                        JOptionPane.showMessageDialog(null, "Position out of bounds. Please enter a valid index.", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        String removedBook = library.getBook(position);
                        library.removeBook(position);
                        updateTable();
                        JOptionPane.showMessageDialog(null, "Book '" + removedBook + "' has been removed from position " + position + ".", "Success", JOptionPane.INFORMATION_MESSAGE);
                        textField.setText("");
                    }
                }
            }
        });
        btnNewButton.setFont(new Font("Arial", Font.BOLD, 20));
        btnNewButton.setBackground(new Color(255, 128, 128));
        btnNewButton.setBounds(668, 462, 135, 30);
        getContentPane().add(btnNewButton);

        textField = new JTextField();
        textField.setForeground(new Color(128, 128, 255)); 
        textField.setHorizontalAlignment(SwingConstants.CENTER);
        textField.setBounds(648, 421, 169, 30);
        getContentPane().add(textField);
        textField.setColumns(10);
        
        
       
        
        JButton btnUndo = new JButton("Undo");
        btnUndo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                library.undo();
                updateTable(); 
            }
        });
        
        
        btnUndo.setForeground(Color.WHITE);
        btnUndo.setFont(new Font("Arial", Font.BOLD, 20));
        btnUndo.setBorder(UIManager.getBorder("ToolBar.border"));
        btnUndo.setBackground(new Color(255, 128, 128));
        btnUndo.setBounds(210, 431, 150, 30);
        getContentPane().add(btnUndo);
        
        JButton btnRedo = new JButton("Redo");
       
        
        
        btnRedo.addActionListener(new ActionListener()
		{ public void actionPerformed(ActionEvent e) 
		{ library.redo(); updateTable(); } });
        
        btnRedo.setForeground(Color.WHITE);
        btnRedo.setFont(new Font("Arial", Font.BOLD, 20));
        btnRedo.setBorder(UIManager.getBorder("ToolBar.border"));
        btnRedo.setBackground(new Color(255, 128, 128));
        btnRedo.setBounds(210, 472, 150, 30);
        getContentPane().add(btnRedo);
    }

    private void updateTable() {
        tableModel.setRowCount(0); 

        int totalBooks = library.getTotalBooks();
        for (int i = 0; i < totalBooks; i++) {
            String position = String.valueOf(i);
            String name = library.getBook(i);
            tableModel.addRow(new Object[]{position, name});
        }
    }

    private boolean isNumeric(String str) {
        return str != null && str.matches("\\d+");
    }
}
