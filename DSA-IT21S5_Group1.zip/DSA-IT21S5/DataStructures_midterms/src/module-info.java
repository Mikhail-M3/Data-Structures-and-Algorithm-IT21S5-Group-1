/**
 * 
 */
/**
 * 
 */
module DataStructures_midterms {
	requires java.desktop;
}