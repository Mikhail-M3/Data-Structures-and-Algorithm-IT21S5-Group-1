package Midterms;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JButton;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class BookTotal extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private LibrarySystem library;
    private DefaultTableModel model; // Declare the model at class level
    private JTable table_1; // Declare the table at class level

    public BookTotal(LibrarySystem library) {
        this.library = library;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 934, 701);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        String[] columnNames = { "Position", "Title" };
        model = new DefaultTableModel(columnNames, 0);
        table_1 = new JTable(model);

        loadBooksIntoTable();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panel_1_1 = new JPanel();
        panel_1_1.setForeground(Color.BLACK);
        panel_1_1.setBackground(new Color(0, 128, 192));
        panel_1_1.setBounds(32, 123, 847, 499);
        contentPane.add(panel_1_1);
        panel_1_1.setLayout(null);

        JScrollPane scrollPane = new JScrollPane((Component) null);
        scrollPane.setBounds(39, 34, 765, 406);
        panel_1_1.add(scrollPane);

        table_1.setRowHeight(30);
        table_1.setFont(new Font("Arial", Font.PLAIN, 16));
        scrollPane.setViewportView(table_1);

        JButton btnNewButton_2_1 = new JButton("Back");
        btnNewButton_2_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Book home = new Book(null);
                home.setVisible(true);
                dispose();
            }
        });
        btnNewButton_2_1.setForeground(Color.BLACK);
        btnNewButton_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnNewButton_2_1.setBackground(Color.WHITE);
        btnNewButton_2_1.setBounds(657, 450, 147, 39);
        panel_1_1.add(btnNewButton_2_1);

        JButton btnSortByName = new JButton("Sort by Name");
        btnSortByName.setForeground(Color.WHITE);
        btnSortByName.setFont(new Font("Monospaced", Font.BOLD, 16));
        btnSortByName.setBorder(UIManager.getBorder("ToolBar.border"));
        btnSortByName.setBackground(new Color(0, 64, 128));
        btnSortByName.setBounds(39, 452, 124, 38);
        panel_1_1.add(btnSortByName);

        // Action listener for sorting books
        btnSortByName.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                bubbleSort();
            }
        });

        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setBounds(0, 85, 690, 576);
        contentPane.add(lblNewLabel_2);

        JPanel panel_1 = new JPanel();
        panel_1.setLayout(null);
        panel_1.setBackground(new Color(0, 128, 192));
        panel_1.setBounds(0, 0, 910, 89);
        contentPane.add(panel_1);

        JLabel lblNewLabel_3 = new JLabel("");
        lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\Anton Patrick\\Desktop\\BookJframe\\logo2.png"));
        lblNewLabel_3.setBounds(20, 9, 80, 73);
        panel_1.add(lblNewLabel_3);

        JLabel lblNewLabel_1_1 = new JLabel("BookWorm Library System");
        lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1_1.setForeground(Color.WHITE);
        lblNewLabel_1_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 35));
        lblNewLabel_1_1.setBounds(213, 9, 480, 54);
        panel_1.add(lblNewLabel_1_1);
        
        BufferedImage img6 = null;
        
        try {
            img6 = ImageIO.read(new File("image/logo2.png"));
        } catch (IOException e) {
            System.out.println("Error loading images: " + e.getMessage());
        }
        
        JLabel lblNewLabell = new JLabel("");
		lblNewLabell.setIcon(new ImageIcon(img6));
		lblNewLabell.setBounds(20, 9, 80, 73);
		panel_1.add(lblNewLabell);
    }

   
    private void loadBooksIntoTable() {
        int totalBooks = library.getTotalBooks();
        for (int i = 0; i < totalBooks; i++) {
            String Position = String.valueOf(i);
            String Title = library.getBook(i);
            model.addRow(new Object[] { Position, Title });
        }
    }

  
    public void bubbleSort() {
        int n = model.getRowCount();
        boolean swapped;

        for (int i = 0; i < n - 1; i++) {
            swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                
                String title1 = (String) model.getValueAt(j, 1);
                String title2 = (String) model.getValueAt(j + 1, 1);
                if (title1.compareTo(title2) > 0) {
                    
                    for (int k = 0; k < model.getColumnCount(); k++) {
                        Object temp = model.getValueAt(j, k);
                        model.setValueAt(model.getValueAt(j + 1, k), j, k);
                        model.setValueAt(temp, j + 1, k);
                    }
                    swapped = true;
                }
            }
            // If no two elements were swapped, the list is 
            if (!swapped) break;
        }
    }

    
    public void updateTable() {
        model.setRowCount(0); 
        loadBooksIntoTable(); 
    }
}
