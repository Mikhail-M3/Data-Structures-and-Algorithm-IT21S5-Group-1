package Midterms;

import java.awt.Component;

public interface LibrarySystem {
	
void addBook(String bookName);
   
 void insertBook(int index, String bookName);
   
 void removeBook(int index);
   
   String getBook(int index);
   
   int getTotalBooks();

  Component getBooks();
  
  String[] sortbooks();

void undo();

void redo();
}
