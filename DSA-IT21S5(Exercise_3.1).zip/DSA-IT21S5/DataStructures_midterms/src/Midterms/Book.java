package Midterms;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Image;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Book extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private LibrarySystem library;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    LibrarySystem library = new Function();
                    Book frame = new Book(library);
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Book(LibrarySystem library) {
        setFont(new Font("Courier New", Font.BOLD, 12));
                setTitle("BOOKWORM LIBRARY SYSTEM");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 995, 704);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
        
        BufferedImage img2 = null;
        BufferedImage img3 = null;
        BufferedImage img4 = null;
        BufferedImage img5 = null;
        BufferedImage img6 = null;

        try {
            img2 = ImageIO.read(new File("image/addBook.png"));
            img3 = ImageIO.read(new File("image/removeBook.png"));
            img4 = ImageIO.read(new File("image/searchBook.png"));
            img5 = ImageIO.read(new File("image/listofBooks.png"));
            img6 = ImageIO.read(new File("image/logo2.png"));
        } catch (IOException e) {
            System.out.println("Error loading images: " + e.getMessage());
        }
        

        
        JPanel panel_1 = new JPanel();
        panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
        panel_1.setBackground(new Color(215, 206, 211));
        panel_1.setBounds(164, 138, 646, 464);
        contentPane.add(panel_1);
        panel_1.setLayout(null);
        
        

        JLabel lblNewLabel_4 = new JLabel("Services");
        lblNewLabel_4.setForeground(new Color(0, 0, 255));
        lblNewLabel_4.setBackground(new Color(128, 128, 128));
        lblNewLabel_4.setFont(new Font("Centaur", Font.BOLD, 50));
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_4.setBounds(129, 11, 386, 65);
        panel_1.add(lblNewLabel_4);

        JButton AddBook = new JButton("Add Books");
        AddBook.setBounds(54, 110, 255, 125);
        panel_1.add(AddBook);
        AddBook.setHorizontalAlignment(SwingConstants.LEFT);
        AddBook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AddBook ab = new AddBook(library);
                ab.setVisible(true);
                dispose();
            }
        });
        AddBook.setFont(new Font("Javanese Text", Font.BOLD, 17));
        AddBook.setForeground(new Color(0, 0, 0));
        AddBook.setBackground(new Color(255, 128, 128));
        AddBook.setIcon(new ImageIcon(img2));
      

        JButton RemoveBooks = new JButton("Remove Books");
        RemoveBooks.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RemoveBook rb = new RemoveBook(library);
                rb.setVisible(true);
                dispose();
            }
        });
        RemoveBooks.setBackground(new Color(255, 128, 128));
        RemoveBooks.setBounds(344, 110, 255, 125);
        panel_1.add(RemoveBooks);
        RemoveBooks.setForeground(Color.BLACK);
        RemoveBooks.setFont(new Font("Javanese Text", Font.BOLD, 16));
        RemoveBooks.setIcon(new ImageIcon(img3));
    

        JButton SearchBook = new JButton("Search Books");
        SearchBook.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SearchBook sBook = new SearchBook(library);
                sBook.setVisible(true);
                dispose();
            }
        });
        SearchBook.setBounds(54, 283, 255, 143);
        panel_1.add(SearchBook);
        SearchBook.setForeground(new Color(0, 0, 0));
        SearchBook.setFont(new Font("Javanese Text", Font.BOLD, 16));
        SearchBook.setBackground(new Color(255, 128, 128));
        SearchBook.setIcon(new ImageIcon(img4));

        JButton ListOfBooks = new JButton("List of Books");
        ListOfBooks.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                BookTotal bNumber = new BookTotal(library);
                bNumber.setVisible(true);
                dispose();
            }
        });
        ListOfBooks.setBounds(344, 283, 255, 143);
        panel_1.add(ListOfBooks);
        ListOfBooks.setForeground(new Color(0, 0, 0));
        ListOfBooks.setFont(new Font("Javanese Text", Font.BOLD, 16));
        ListOfBooks.setBackground(new Color(255, 128, 128));
        ListOfBooks.setIcon(new ImageIcon(img5));
       

        JLabel lblNewLabel_3 = new JLabel("");
        lblNewLabel_3.setBounds(0, 89, 0, 0);
        contentPane.add(lblNewLabel_3);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(0, 128, 192));
        panel.setBounds(0, 0, 979, 89);
        contentPane.add(panel);
        panel.setLayout(null);

        JLabel lblNewLabel = new JLabel("");
      
        lblNewLabel.setBounds(20, 9, 80, 73);
        panel.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("BookWorm Library System");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("SansSerif", Font.BOLD | Font.ITALIC, 35));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(198, 15, 595, 54);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabell = new JLabel("");
		lblNewLabell.setIcon(new ImageIcon(img6));
		lblNewLabell.setBounds(20, 9, 80, 73);
		panel.add(lblNewLabell);
}
}