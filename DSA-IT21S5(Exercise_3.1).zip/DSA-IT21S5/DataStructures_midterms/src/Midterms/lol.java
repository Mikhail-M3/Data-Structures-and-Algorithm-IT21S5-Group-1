package Midterms;

import java.util.ArrayList;

public class lol { 

    // Bubble Sort using ArrayList
    void bubbleSort(ArrayList<Integer> arr) { 
        int n = arr.size(); 
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false; // Track if a swap occurred
            for (int j = 0; j < n - i - 1; j++) {
                // Compare adjacent elements
                if (arr.get(j) > arr.get(j + 1)) { 
                    // Swap if they are in the wrong order
                    int temporary = arr.get(j); 
                    arr.set(j, arr.get(j + 1)); 
                    arr.set(j + 1, temporary); 
                    swapped = true; // Set the swapped flag
                    System.out.println("Step " + ":");
                    printArray(arr);
                }
            }
            // If no two elements were swapped in the inner loop, the list is sorted
            if (!swapped) break;
        } 
    } 

    // Method to print the ArrayList
    void printArray(ArrayList<Integer> arr) { 
        for (int i = 0; i < arr.size(); i++) 
            System.out.print(arr.get(i) + " "); 
        System.out.println(); 
    } 

    public static void main(String args[]) { 
        lol example = new lol(); 
        ArrayList<Integer> arr = new ArrayList<>();
        
        // Adding elements to the ArrayList
        arr.add(2);
        arr.add(10);
        arr.add(15);
        arr.add(4);
        arr.add(1);
        arr.add(18);
        arr.add(6);
        arr.add(5);
        
        System.out.println("---Bubble Sorting Method---"); 
        System.out.println("---------------------------"); 
        
        example.bubbleSort(arr); 
        System.out.println("\nSorted array:"); 
        example.printArray(arr);
    } 
}
