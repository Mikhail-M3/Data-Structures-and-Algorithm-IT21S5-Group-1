package Prelim;

public interface LibraryManagementSystem {
	
   abstract void addBook(String bookName);
   
   abstract void insertBook(int index, String bookName);
   
   abstract void removeBook(int index);
   
   abstract String getBook(int index);
   
   abstract  int getTotalBooks();
}
