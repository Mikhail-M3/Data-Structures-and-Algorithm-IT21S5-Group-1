/**
 * 
 */
/**
 * 
 */
module IT21S5_DSA {
	requires java.desktop;
}